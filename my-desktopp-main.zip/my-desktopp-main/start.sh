#!/usr/bin/env bash
set -euo pipefail

PORT="${PORT:-8080}"
DISPLAY_NUM=1
RFB_PORT=5901
export DISPLAY=":${DISPLAY_NUM}"

# ---------------------------------------------------------------
# 0. Resolve binary names.
#    Debian prefixes every TigerVNC binary with "tiger":
#      vncpasswd -> tigervncpasswd   (package tigervnc-tools)
#      Xvnc      -> Xtigervnc        (package tigervnc-standalone-server)
#    Other distros use the plain names, so probe for both.
# ---------------------------------------------------------------
VNCPASSWD="$(command -v tigervncpasswd || command -v vncpasswd || true)"
XVNC="$(command -v Xtigervnc || command -v Xvnc || true)"

if [ -z "$VNCPASSWD" ]; then
  echo "FATAL: no vncpasswd binary found. Install tigervnc-tools."
  exit 1
fi
if [ -z "$XVNC" ]; then
  echo "FATAL: no Xvnc binary found. Install tigervnc-standalone-server."
  exit 1
fi
echo ">> using passwd tool: $VNCPASSWD"
echo ">> using vnc server : $XVNC"

# ---------------------------------------------------------------
# 1. VNC password
# ---------------------------------------------------------------
if [ -z "${VNC_PASSWORD:-}" ]; then
  VNC_PASSWORD="$(tr -dc 'a-z2-9' < /dev/urandom | head -c 8)"
  echo "############################################################"
  echo "#  VNC_PASSWORD was not set."
  echo "#  Generated a temporary one for this deployment:"
  echo "#"
  echo "#      $VNC_PASSWORD"
  echo "#"
  echo "#  It changes on every restart. Set VNC_PASSWORD in the"
  echo "#  Railway Variables tab, then click the Deploy button at the"
  echo "#  top of the canvas to apply the staged change."
  echo "############################################################"
fi

mkdir -p "$HOME/.vnc"
# VNC truncates the password at 8 characters. That is a protocol limit.
printf '%s\n' "$VNC_PASSWORD" | "$VNCPASSWD" -f > "$HOME/.vnc/passwd"
chmod 600 "$HOME/.vnc/passwd"

# ---------------------------------------------------------------
# 2. Start Xvnc directly.
#    The tigervncserver wrapper wants /etc/tigervnc/vncserver.users and a
#    systemd session, neither of which exists in a container.
#    -localhost keeps 5901 unreachable from outside; only noVNC and the
#    optional ngrok agent, both inside this container, can reach it.
# ---------------------------------------------------------------
GEOMETRY="${VNC_GEOMETRY:-1280x720}"
rm -f "/tmp/.X${DISPLAY_NUM}-lock" "/tmp/.X11-unix/X${DISPLAY_NUM}"

"$XVNC" ":${DISPLAY_NUM}" \
  -geometry "$GEOMETRY" \
  -depth 24 \
  -rfbport "$RFB_PORT" \
  -rfbauth "$HOME/.vnc/passwd" \
  -SecurityTypes VncAuth \
  -localhost \
  -AlwaysShared &
XVNC_PID=$!

# Wait for the RFB socket instead of a blind sleep.
for i in $(seq 1 30); do
  if (echo > /dev/tcp/127.0.0.1/${RFB_PORT}) >/dev/null 2>&1; then
    echo ">> VNC listening on 127.0.0.1:${RFB_PORT} (${GEOMETRY})"
    break
  fi
  if ! kill -0 "$XVNC_PID" 2>/dev/null; then
    echo "FATAL: Xvnc died during startup."
    exit 1
  fi
  sleep 1
done

# ---------------------------------------------------------------
# 3. XFCE session on that display
# ---------------------------------------------------------------
dbus-launch --exit-with-session startxfce4 >/tmp/xfce.log 2>&1 &
echo ">> XFCE session starting"

# ---------------------------------------------------------------
# 4. Optional ngrok TCP tunnel for native VNC clients
# ---------------------------------------------------------------
if [ -n "${NGROK_AUTHTOKEN:-}" ]; then
  echo ">> starting ngrok TCP tunnel to ${RFB_PORT}"
  python3 /app/ngrok_tunnel.py &
else
  echo ">> NGROK_AUTHTOKEN not set - skipping tunnel, use the noVNC web URL"
fi

# ---------------------------------------------------------------
# 5. noVNC on Railway's $PORT
# ---------------------------------------------------------------
echo ">> serving noVNC on 0.0.0.0:${PORT}"
exec /opt/noVNC/utils/novnc_proxy \
  --vnc "localhost:${RFB_PORT}" \
  --listen "0.0.0.0:${PORT}"
