# XFCE Desktop over noVNC — Railway deploy

A cleaned-up rework of `ekefddfjoeroe/Railway-RDP`. Debian bookworm + XFCE, served
in the browser via noVNC, with an optional ngrok TCP tunnel for native VNC clients.

**This is VNC, not RDP.** There is no RDP server anywhere in the original repo either.

## Environment variables

| Variable | Required | Notes |
|---|---|---|
| `VNC_PASSWORD` | **yes** | Container refuses to boot without it. Max 8 effective chars (VNC protocol limit). |
| `PORT` | auto | Railway injects this. Don't set it manually. |
| `VNC_GEOMETRY` | no | Default `1280x720`. Lower it to save RAM. |
| `NGROK_AUTHTOKEN` | no | Only if you want a native VNC client. Needs a card-verified ngrok account. |

## Deploy

```bash
# 1. put these files in a fresh repo
git init && git add . && git commit -m "init"
gh repo create my-desktop --private --source=. --push

# 2. deploy
npm i -g @railway/cli
railway login
railway init
railway up

# 3. set the password, then generate a public URL
railway variables --set "VNC_PASSWORD=changeme"
railway domain
```

Open the domain, click **Connect**, enter your password.

## Changes from the original

- Base image `catub/core:bullseye` (unmaintained, opaque) → `debian:bookworm-slim`
- **VNC password enforced**; server bound to `-localhost yes` instead of listening on 0.0.0.0 with no auth
- Dropped the dead ChromeDriver 88 pin, `apt-key` usage, `postgresql-${PG_MAJOR}` (undefined var), qemu, the `docker` tray applet, and the `bbht` remote install script
- Dropped `rm /railway/Dockerfile` at runtime
- websockify vendored properly so `novnc_proxy` actually works
- Image is roughly 1.5 GB instead of ~7 GB

## Known limits

- Railway has no free tier. $5 trial credit, card required, 30 days.
- A 24/7 desktop at 0.5 vCPU / 1 GB burns through $5 in well under a week.
- Railway's ToS disallows using the platform as a general remote desktop / tunnel. Expect this to get flagged.
- Ephemeral filesystem — everything is wiped on redeploy unless you attach a volume.
