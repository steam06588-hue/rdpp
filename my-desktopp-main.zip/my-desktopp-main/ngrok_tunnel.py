import json
import os
import time

from pyngrok import conf, ngrok

token = os.environ.get("NGROK_AUTHTOKEN")
if not token:
    raise SystemExit("NGROK_AUTHTOKEN not set")

conf.get_default().auth_token = token

# TCP endpoints require a card-verified ngrok account (free tier is fine,
# the card is only used for identity verification and is not charged).
tunnel = ngrok.connect(5901, "tcp")

print("=" * 60, flush=True)
print("NGROK VNC ADDRESS:", tunnel.public_url, flush=True)
print("Point your VNC client at the host:port after tcp://", flush=True)
print("=" * 60, flush=True)

with open("/tmp/ngrok.json", "w") as fh:
    json.dump(tunnel.data, fh, indent=2)

try:
    while True:
        time.sleep(3600)
except KeyboardInterrupt:
    ngrok.kill()
